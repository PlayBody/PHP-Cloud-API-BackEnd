<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . '/models/Base_model.php';
class User_model extends Base_model
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'users';
        $this->primary_key = 'user_id';
    }

    public function getRecordByCond($cond){
        $this->db->from($this->table);
        $this->db->where('del_flag', '0');

        if (!empty($cond['user_no'])){
            $this->db->where('user_no', $cond['user_no']);
        }

        $query = $this->db->get();
        return $query->row_array();

    }

    public function getUsersByCond($cond){
        $this->db->from($this->table);

//        if (!empty($cond['user_no'])){
//            $this->db->where('user_no', $cond['user_no']);
//        }

        $query = $this->db->get();
        return $query->result_array();

    }

    public function getUsersWithIsGroup($company_id, $group_id){
        $sql  = 'select *, 
            if (user_id in (select user_id from group_users where group_id = '.$group_id.'), 1,0) as is_group 
        from users 
            where company_id = ' . $company_id;

        $query = $this->db->query($sql);

        return $query->result_array();
    }
}

  