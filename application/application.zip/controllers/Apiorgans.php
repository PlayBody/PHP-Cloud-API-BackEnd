<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'core/WebController.php';

class Apiorgans extends WebController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->model('staff_model');
        $this->load->model('organ_model');
        $this->load->model('staff_organ_model');
        $this->load->model('organ_setting_model');
    }

    public function loadOrganList(){
        $organs = $this->organ_model->getListByCond([]);

        $results['isLoad'] = true;
        $results['organs'] = $organs;
        echo(json_encode($results));

    }

    public function loadOrganInfo(){
        $organ_id = $this->input->post('organ_id');
        $organ = $this->organ_model->getFromId($organ_id);

        $bosses = $this->staff_organ_model->getBossessByOrgan($organ_id);

        $results['isLoad'] = true;
        $results['organ'] = $organ;
        $results['staffs'] = $bosses;
        echo(json_encode($results));

    }
    public function deleteOrgan(){
        $organ_id = $this->input->post('organ_id');

        if (empty($organ_id)){
            $results['isDelete'] = false;
            echo json_encode($results);
            return;
        }

        $this->organ_model->delete_force($organ_id, 'organ_id');
        $this->staff_organ_model->delete_force($organ_id, 'organ_id');
        $this->organ_setting_model->delete_force($organ_id, 'organ_id');

        $results['isDelete'] = true;

        echo(json_encode($results));

    }

    public function saveOrgan(){
        $organ_id = $this->input->post('organ_id');
        $organ_name = $this->input->post('organ_name');


        if (empty($organ_id)){
            $organ['organ_name'] = $organ_name;
            $organ['del_flag'] = 0;
            $organ['create_date'] = date('Y-m-d H:i:s');
            $organ['update_date'] = date('Y-m-d H:i:s');

            $organ_id = $this->organ_model->add($organ);
        }else{
            $organ = $this->organ_model->getFromId($organ_id);
            $organ['organ_name'] = $organ_name;
            $organ['update_date'] = date('Y-m-d H:i:s');

            $this->organ_model->edit($organ, 'organ_id');
        }

        $results['isSave'] = true;
        $results['organ_id'] = $organ_id;

        echo(json_encode($results));

    }

    public function createBossAccount(){
        $organ_id = $this->input->post('organ_id');

        $pool = '0123456789abcdefghijklmnopqrstuvwxyz';

        $staff = ['staff'];

        while(!empty($staff)){
            $account = substr(str_shuffle(str_repeat($pool, 6)), 0, 6)."@sample.com";
            $staff = $this->staff_model->getStaffList(['staff_mail'=>$account]);
        }


        $add_staff = array(
            'staff_auth' => 1,
            'staff_first_name' => 'auto',
            'staff_last_name' => 'boss',
            'staff_tel' => '0000',
            'staff_mail' => $account,
            'staff_sex' => 1,
            'staff_birthday' => date('Y-m-d'),
            'staff_password' => sha1('12345'),
            'del_flag' => 0,
            'create_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        $staff_id = $this->staff_model->add($add_staff);

        $add_staff_organs = array(
            'staff_id' => $staff_id,
            'organ_id' => $organ_id,
            'auth' => 4
        );

        $this->staff_organ_model->add($add_staff_organs );


        $results['isCreate'] = true;

        echo(json_encode($results));
    }

    public function deleteBossAccount(){
        $staff_id = $this->input->post('staff_id');

        if (empty($staff_id)){
            $results['isDelete'] = false;
            echo json_encode($results);
            return;
        }

        $this->staff_model->delete_force($staff_id, 'staff_id');

        $this->staff_organ_model->delete_force($staff_id, 'staff_id');

        $results['isDelete'] = true;

        echo(json_encode($results));

    }
}
?>