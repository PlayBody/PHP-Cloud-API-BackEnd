<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'core/WebController.php';

/*
 *
 */

class Apishifts extends WebController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->model('organ_model');
        $this->load->model('shift_model');
        $this->load->model('staff_model');
    }

    public function loadShifts(){

        $staff_id = $this->input->post('staff_id');
        $organ_id = $this->input->post('organ_id');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');

        $results = [];

        if (empty($staff_id) || empty($organ_id)){
            $results['isLoad'] = false;
            echo json_encode($results);
            return;
        }

        $organ = $this->organ_model->getFromId($organ_id);
        $staff = $this->staff_model->getFromId($staff_id);

        if (empty($organ) || empty($staff)){
            $results['isLoad'] = false;
            echo json_encode($results);
            return;
        }

        $organ_active_start = empty($organ['active_start_time']) ? '00:00' : $organ['active_start_time'];
        $organ_active_end = empty($organ['active_end_time']) ? '24:00' : $organ['active_end_time'];

        $shift_inactive = [];

        $cur_date = $from_date;
        while($cur_date<=$to_date){
            $tmp = [];
            $tmp['from'] = $cur_date. ' 00:00:00';
            $tmp['to'] = $cur_date. ' ' .$organ_active_start;
            $tmp['type'] = '5';

            $shift_inactive[] = $tmp;

            $tmp = [];
            $tmp['from'] = $cur_date. ' ' .$organ_active_end;
            $tmp['to'] = $cur_date. ' 23:59:59';
            $tmp['type'] = '5';

            $shift_inactive[] = $tmp;


            $diff1Day = new DateInterval('P1D');

            $curDateTime = new DateTime($cur_date);

            $curDateTime->add($diff1Day);
            $cur_date = $curDateTime->format("Y-m-d");
        }

        $cond = array();
        $cond['staff_id'] = $staff_id;
        $cond['organ_id'] = $organ_id;
        $cond['from_time'] = $from_date.' 00:00:00';
        $cond['to_time'] = $to_date.' 23:59:59';

        $staff_shift_list = $this->shift_model->getListByCond($cond);

        $shift = [];
        foreach ($staff_shift_list as $item) {
            $tmp = [];
            $tmp['from'] = $item['from_time'];
            $tmp['to'] = $item['to_time'];
            $tmp['type'] = $item['shift_type'];

            $shift[] = $tmp;
        }

        $results['isLoad'] = true;
        $results['shift'] = $shift;
        $results['shift_inactive'] = $shift_inactive;

        echo(json_encode($results));
    }

    public function loadShiftStatus(){
        $staff_id = $this->input->post('staff_id');
        $organ_id = $this->input->post('organ_id');
        $select_datetime = $this->input->post('select_datetime');

        $cond = array();
        $cond['staff_id'] = $staff_id;
        $cond['organ_id'] = $organ_id;
        $cond['select_datetime'] = $select_datetime;
        $shifts = $this->shift_model->getListByCond($cond);

        $results = [];
        $results['isLoad'] = true;

        if (empty($shifts)){
            $results['status'] = '0';
        }else{
            $results['start_time'] = $shifts[0]['from_time'];
            $results['end_time'] = $shifts[0]['to_time'];
            $results['status'] = $shifts[0]['shift_type'];
            $results['shift_id'] = $shifts[0]['shift_id'];
        }

        echo json_encode($results);
        return;
    }

    public function submitShift(){
        $staff_id = $this->input->post('staff_id');
        $organ_id = $this->input->post('organ_id');
        $select_date = $this->input->post('select_date');
        $start_time = $this->input->post('start_time');
        $end_time = $this->input->post('end_time');

        $from_time = $select_date. ' ' . $start_time;
        $to_time = $select_date. ' ' . $end_time;

        $shift = array(
            'staff_id' => $staff_id,
            'organ_id' => $organ_id,
            'from_time' => $from_time,
            'to_time' => $to_time,
            'shift_type' => 1,
            'visible' => 1,
        );

        $insert = $this->shift_model->insertRecord($shift);

        $results=[];
        if (!$insert){
            $results['isUpdate'] = false;
            echo json_encode($results);
            return;
        }

        $results['isUpdate'] = true;
        echo json_encode($results);
        return;
    }

    public function actionStaffShift(){
        $shift_id = $this->input->post('shift_id');
        $status = $this->input->post('status');

        $results=[];

        if (empty($shift_id)){
            $results['isUpdate'] = false;
            echo json_encode($results);
            return;
        }

        $shift = $this->shift_model->getFromId($shift_id);

        if (empty($shift)){
            $results['isUpdate'] = false;
            echo json_encode($results);
            return;
        }

        $shift['shift_type'] = $status;

        $this->shift_model->updateRecord($shift, 'shift_id');


        $results['isUpdate'] = true;
        echo json_encode($results);
        return;

    }

}
?>