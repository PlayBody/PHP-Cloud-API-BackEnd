<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'core/WebController.php';

/*
 *
 */

class Api_reserve extends WebController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->model('pos_staff_model');
        $this->load->model('pos_member_model');


        $this->load->model('crm_reserve_model');
        $this->load->model('crm_reserve_menu_model');
        $this->load->model('pos_staff_shift_model');
    }

    public function load_reserve_data()
    {

        $user_id = $this->input->post('user_id');
        $member_id = $this->input->post('member_id');
        $staff_id = $this->input->post('staff_id');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');

        $results = [];

        if (empty($member_id) || empty($user_id)){
            $results['isLoaded'] = false;
            echo json_encode($results);
            return;
        }

        $staff_list = $this->pos_staff_model->getListByCondition(['member_id'=>$member_id]);

        $member = $this->pos_member_model->getFromId($member_id);



        if (empty($member['crm_start_time'])) $member['crm_start_time'] = '0';
        if (empty($member['crm_end_time'])) $member['crm_end_time'] = '24';
        if (empty($member['accounting_count'])) $member['accounting_count'] = '7';


        $results = [];

        $cur_date = $from_date;
        while($cur_date<=$to_date){
            if ($cur_date<date('Y-m-d')){
                    $tmp = [];
                    $tmp['from_time'] = $cur_date. ' ' .'00:00:00';
                    $tmp['to_time'] = $cur_date. ' ' .'24:00:00';
                    $tmp['type'] = '0';

                    $reserve_time_data[] = $tmp;
            }else{
                for ($i=$member['crm_start_time'];$i<$member['crm_end_time'];$i++) {
                    $tmp = [];

                    $ii = $i;
                    $iadd = $i+1;
                    if ($ii<10) $ii = '0'.$ii;
                    if ($iadd<10) $iadd = '0'.$iadd;

                    $tmp['from_time'] = $cur_date. ' ' .$ii.':00:00';
                    $tmp['to_time'] = $cur_date. ' ' .$iadd.':00:00';
                    $tmp['type'] = '1'; //free

                    $cur_time = $cur_date. ' ' .$ii.':00:00';

                    $isReserve = $this->crm_reserve_model->isExistMyReserve($user_id, $member_id, $cur_time);
                    if ($isReserve){
                        $tmp['type'] = '2'; //owner reserve
                    }else{
                        $reserveCount = $this->crm_reserve_model->getReserveCount($member_id, $cur_time);
                        if ($member['accounting_count']<=$reserveCount){
                            $tmp['type'] = '3';
                        }else{
                            if (!empty($staff_id)){
                                $isExistStaff = $this->crm_reserve_model->isExistStaff($staff_id, $cur_time);
                                if ($isExistStaff){
                                    $tmp['type'] = '3';
                                }else{
                                    $isStaffShiftReject = $this->pos_staff_shift_model->isStaffShiftReject($staff_id, $cur_time);
                                    if ($isStaffShiftReject){
                                        $tmp['type'] = '3';  
                                    }

                                }
                            }
                        }
                    }

                    $reserve_time_data[] = $tmp;
                }

            }
            $diff1Day = new DateInterval('P1D');

            $curDateTime = new DateTime($cur_date);

            $curDateTime->add($diff1Day);
            $cur_date = $curDateTime->format("Y-m-d");
        }
 
        $results['isLoaded'] = true;
        $results['reserve_time_data'] = $reserve_time_data;
        $results['staffs'] = $staff_list;
        $results['crm_start_time'] = $member['crm_start_time'];
        $results['crm_end_time'] = $member['crm_end_time'];

        echo(json_encode($results));

    }

    function register_reserve_data(){
        $member_id = $this->input->post('member_id');
        $user_id = $this->input->post('user_id');
        $staff_id = $this->input->post('staff_id');
        $start_time = $this->input->post('start_time');
        $end_time = $this->input->post('end_time');
        $reserve_menu = $this->input->post('reserve_menu');
        $results = [];
        if (empty($member_id) || empty($user_id)){
            $results['isSaved'] = false;
            echo json_encode($results);
            return;
        }

        $reserve = array(
            'user_id' => $user_id,
            'member_id' => $member_id,
            'staff_id' => empty($staff_id) ? null : $staff_id,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'del_flag' => 0,
            'create_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s')
        );      

        $reserve_id = $this->crm_reserve_model->add($reserve);

        if (empty($reserve_id)){
            $results['isSaved'] = false;
            echo json_encode($results);
            return;
        }

        $data = json_decode($reserve_menu);

        foreach ($data as $record) {
            $insertData = [];
            $insertData = array(
                'reserve_id' => $reserve_id,
                'menu_id' => $record->menu_id,
                'del_flag' => 0,
                'create_date' => date('Y-m-d'),
                'update_date' => date('Y-m-d'),
            );

            $insert = $this->crm_reserve_menu_model->add($insertData);
        }

        $results['isSaved'] = true;
        echo json_encode($results);

        return;
    }

}
?>