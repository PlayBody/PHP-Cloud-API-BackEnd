<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'core/WebController.php';

/*
 *
 */

class Apiusers extends WebController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
    }

    public function loadUserFromQrNo(){
        $user_no = $this->input->post('user_no');

        if (empty($user_no)){
            $results['isLoad'] = false;
            echo json_encode($results);
            return;
        }

        $user = $this->user_model->getRecordByCond(['user_no'=>$user_no]);

        if (empty($user)){
            $results['isLoad'] = false;
            echo json_encode($results);
            return;
        }

        $results['isLoad'] = true;
        $results['user'] = $user;

        echo json_encode($results);
    }

    public function loadUserList(){
//        $user_no = $this->input->post('user_no');

        $user = $this->user_model->getRecordByCond(['user_no'=>$user_no]);

        if (empty($user)){
            $results['isLoad'] = false;
            echo json_encode($results);
            return;
        }

        $results['isLoad'] = true;
        $results['user'] = $user;

        echo json_encode($results);
    }
}
?>