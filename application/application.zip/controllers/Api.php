<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'core/WebController.php';

/*
 *
 */

class Api extends WebController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->model('app_version_model');
    }

    public function loadAppVersion(){
        $app_id = $this->input->post('app_id');
        $os_type= $this->input->post('os_type');
        $data = $this->app_version_model->getLastVersion($app_id, $os_type);

        $results['isLoad'] = true;
        $results['version'] = $data['version_no'];
        $results['build'] = $data['build_no'];

        echo json_encode($results);
    }

}
?>